FlashFork
==========

An Anki addon for copying decks of flashcards, with or without also copying their note types.
See the Anki website's list of provided addons.
