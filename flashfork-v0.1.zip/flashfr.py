"""
Anki addon that lets you copy a deck.
"""

from flashfork import copydeck
